document.getElementById('water').onclick = function () {
    if(document.getElementById("ID1").src == "http://localhost:7998/icon/vide.png"){
document.getElementById("ID1").src = "icon/water.png";

}
else if(document.getElementById("ID2").src == "http://localhost:7998/icon/vide.png") {
document.getElementById("ID2").src = "icon/water.png";
}
else if(document.getElementById("ID3").src == "http://localhost:7998/icon/vide.png") {
document.getElementById("ID3").src = "icon/water.png";
}
}
document.getElementById('fire').onclick = function () {
    if(document.getElementById("ID1").src == "http://localhost:7998/icon/vide.png"){
    document.getElementById("ID1").src = "icon/fire.png";
    }
    else if(document.getElementById("ID2").src == "http://localhost:7998/icon/vide.png") {
document.getElementById("ID2").src = "icon/fire.png";
}
else if(document.getElementById("ID3").src == "http://localhost:7998/icon/vide.png") {
document.getElementById("ID3").src = "icon/fire.png";
}
  }
  document.getElementById('ID1').onclick = function () {
    document.getElementById("ID1").src = "icon/vide.png";
    var div = document.getElementById("ID1");
    div.appendChild(img);
  }
  document.getElementById('ID2').onclick = function () {
    document.getElementById("ID2").src = "icon/vide.png";
    var div = document.getElementById("ID2");
    div.appendChild(img);
  }
  document.getElementById('ID3').onclick = function () {
    document.getElementById("ID3").src = "icon/vide.png";
    var div = document.getElementById("ID3");
    div.appendChild(img);
  }
  document.getElementById('fusion').onclick = function () 
  {
    if((document.getElementById("ID1").src == "http://localhost:7998/icon/water.png") && (document.getElementById("ID2").src == "http://localhost:7998/icon/water.png") )
    {
        document.getElementById("ocean").style.display = "block"
    }
  }
    